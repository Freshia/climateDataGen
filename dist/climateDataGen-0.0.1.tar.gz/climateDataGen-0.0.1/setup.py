from setuptools import setup
setup(
    name = 'climateDataGen',
    version= '0.0.1',
    packages = ['climateDataGen'],
    author = 'Sackey Freshia'
)