from setuptools import setup
setup(
    name = 'climateDataGen',
    version= '0.2.2',
    packages = ['climateDataGen'],
    author = 'Sackey Freshia'
)